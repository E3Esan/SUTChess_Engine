# SUT Chess

A Java Swing project for building a chess game. The current version opens a desktop window and draws an 8 × 8 checkerboard. Chess pieces, player input, legal moves, and game rules have not been implemented yet.

## Requirements

- JDK 17 or later
- A desktop environment capable of displaying Swing windows

## Run

From the project directory, compile the Java source files and start the application:

```sh
mkdir -p bin
javac -d bin src/*.java
java -cp bin Main
```

In VS Code, you can also open the project folder and run `Main.java` as a Java application.

## Project structure

```text
src/
  Main.java       Creates and displays the application window
  GamePanel.java  Runs the game loop and paints the panel
  Board.java      Draws the checkerboard
bin/              Compiled Java classes (generated)
```

All source classes currently use Java's default package.

## Current behavior

- Creates a non-resizable 900 × 900 Swing window.
- Draws an 8 × 8 board with alternating light and dark squares.
- Repaints the game panel from a simple game loop.

## Possible next steps

- Draw chess pieces on the board.
- Handle mouse input to select and move pieces.
- Implement legal-move validation, turns, check, and checkmate.
